#!/usr/bin/env python3
"""Translate the verified PRG0 instruction map to C control flow."""

import argparse
from collections import defaultdict
import gzip
import hashlib
import json
from pathlib import Path


PRG0_SHA256 = '8f72dc2e98572eb4ba7c3a902bca5f69c448fc4391837e5f8f0d4556280440ac'
CHUNK = 0x400
ORIGINS = [0x8000] * 7 + [0xc000, 0x6000]
REG = dict(LDA='a', LDX='x', LDY='y', STA='a', STX='x', STY='y',
           CMP='a', CPX='x', CPY='y')
BRANCH = dict(BCC='!(p & Z_C)', BCS='p & Z_C', BEQ='p & Z_Z',
              BNE='!(p & Z_Z)', BMI='p & Z_N', BPL='!(p & Z_N)',
              BVC='!(p & Z_V)', BVS='p & Z_V')
C, Z, V, N = 1, 2, 64, 128
ALL_FLAGS = 255
BRANCH_READ = dict(BCC=C, BCS=C, BEQ=Z, BNE=Z, BMI=N, BPL=N, BVC=V, BVS=V)
NZ_OPS = frozenset('LDA LDX LDY AND ORA EOR INC DEC INX INY DEX DEY TAX TAY TXA TYA TSX PLA'.split())
CNZ_OPS = frozenset('CMP CPX CPY ASL LSR ROL ROR'.split())


def hex_c(value):
    return f'0x{value:04x}'


def update_generated(path, content):
    if not path.exists() or path.read_text() != content:
        path.write_text(content)


def read_catalogue(path, prg):
    catalogue = json.loads(gzip.decompress(path.read_bytes()))
    regions = defaultdict(dict)
    # The exact PRG0 hash is checked by both entry points before this call.
    # The catalogue contains locations and instruction lengths, not ROM bytes.
    for group, pc, offset, length, mnemonic, mode in catalogue:
        raw = prg[offset:offset + length]
        if len(raw) != length:
            raise ValueError(f'Truncated PRG0 at {offset:05x} / {pc:04x}')
        if not ORIGINS[group] <= pc < ORIGINS[group] + 0x4000 or pc in regions[group]:
            raise ValueError(f'Duplicate or invalid instruction at {group}:{pc:04x}')
        regions[group][pc] = (raw, mnemonic, mode)
    if len(catalogue) != 18998:
        raise ValueError('Incomplete instruction map')
    return regions


def effective_addr(mode, operand):
    base = hex_c(operand)
    return {
        'abs': base, 'zp': base, 'absx': f'(uint16_t)({base} + x)',
        'absy': f'(uint16_t)({base} + y)', 'zpx': f'(uint8_t)({base} + x)',
        'zpy': f'(uint8_t)({base} + y)', 'indy': f'(uint16_t)(m->ram[{base}] +'
        f' ((uint16_t)m->ram[{hex_c((operand + 1) & 255)}] << 8) + y)',
    }[mode]


def read_value(mode, operand, pc, group):
    if mode == 'imm':
        return hex_c(operand)
    if mode == 'acc':
        return 'a'
    address = effective_addr(mode, operand)
    if mode in ('zp', 'zpx', 'zpy') or (mode == 'abs' and operand < 0x0800) or (
            mode in ('absx', 'absy') and operand <= 0x0700):
        return f'm->ram[{address}]'
    limit = operand + (255 if mode in ('absx', 'absy') else 0)
    if mode in ('abs', 'absx', 'absy'):
        if 0xc000 <= operand and limit <= 0xffff and group == 7:
            return f'lift_prg[0x1c000 | ({address} & 0x3fff)]'
        if 0x8000 <= operand and limit < 0xc000 and group < 7:
            return f'lift_prg[0x{group << 14:05x} | ({address} & 0x3fff)]'
    return f'lift_read(m, {address}, {hex_c(pc)})'


def write_value(mode, operand, value, group, pc, next_pc):
    if mode == 'acc':
        return f'a = {value};'
    address = effective_addr(mode, operand)
    if mode in ('zp', 'zpx', 'zpy') or (mode == 'abs' and operand < 0x0800) or (
            mode in ('absx', 'absy') and operand <= 0x0700):
        return f'm->ram[{address}] = {value};'
    code = f'lift_write(m, {address}, {value});'
    possible_mapper = mode == 'indy' or operand >= (0x7f01 if mode != 'abs' else 0x8000)
    if possible_mapper and group != 8:
        mapped_bank = 'high_bank' if pc >= 0xc000 else 'low_bank'
        code += f' if (m->{mapped_bank} != {group}) {{ next = {hex_c(next_pc)}; goto yield; }}'
    return code


def branch_target(pc, operand):
    return (pc + 2 + (operand - 256 if operand >= 128 else operand)) & 0xffff


def flag_usage(op):
    read = BRANCH_READ.get(op, C if op in ('ADC', 'SBC', 'ROL', 'ROR') else 0)
    if op in NZ_OPS:
        return read, N | Z
    if op in CNZ_OPS:
        return read, C | N | Z
    if op in ('ADC', 'SBC'):
        return read, C | N | Z | V
    if op == 'BIT':
        return read, N | Z | V
    if op == 'PHP':
        return ALL_FLAGS, 0
    if op in ('PLP', 'RTI'):
        return 0, ALL_FLAGS
    writes = dict(CLC=C, SEC=C, CLV=V, CLD=8, SED=8, CLI=4, SEI=4)
    return read, writes.get(op, 0)


def flag_liveness(local):
    successors = {}
    uses = {}
    for pc, (raw, op, mode) in local.items():
        operand = int.from_bytes(raw[1:], 'little')
        next_pc = (pc + len(raw)) & 0xffff
        uses[pc] = flag_usage(op)
        if op in BRANCH:
            successors[pc] = (next_pc, branch_target(pc, operand))
        elif op in ('JMP', 'JSR'):
            successors[pc] = (operand,) if mode != 'ind' else (None,)
        elif op in ('RTS', 'RTI'):
            successors[pc] = (None,)
        elif op.startswith('ST') and (mode == 'indy' or operand >= 0x7f01):
            successors[pc] = (next_pc, None)
        else:
            successors[pc] = (next_pc,)
    incoming = dict.fromkeys(local, 0)
    outgoing = dict.fromkeys(local, 0)
    while True:
        changed = False
        for pc in reversed(local):
            flags = 0
            for target in successors[pc]:
                flags |= incoming.get(target, ALL_FLAGS)
            outgoing[pc] = flags
            read, written = uses[pc]
            needed = read | (flags & ~written)
            if incoming[pc] != needed:
                changed = True
                incoming[pc] = needed
        if not changed:
            return outgoing


def store_flags(flags, value, extra=None):
    if not flags:
        return ''
    terms = [f'(p & ~{flags})']
    if flags & N:
        terms.append(f'(({value}) & Z_N)')
    if flags & Z:
        terms.append(f'(({value}) == 0 ? Z_Z : 0)')
    if extra:
        terms.extend(expr for flag, expr in extra.items() if flags & flag)
    return ' p = ' + ' | '.join(terms) + ';'


def translate_instruction(group, pc, instruction, local, live):
    raw, op, mode = instruction
    operand = int.from_bytes(raw[1:], 'little')
    next_pc = (pc + len(raw)) & 0xffff

    def jump(target):
        addr = hex_c(target)
        if target not in local or target == 0xe45b:
            return f'next = {addr}; goto yield;'
        stop = (f'if (m->fuel == 0) {{ next = {addr}; goto yield; }} --m->fuel; '
                if target <= pc else '')
        return f'{stop}goto L_{target:04x};'

    def load():
        return read_value(mode, operand, pc, group)

    def write(value):
        return write_value(mode, operand, value, group, pc, next_pc)

    if op in BRANCH:
        target = branch_target(pc, operand)
        if group == 7 and pc in (0xff5f, 0xff66):
            # Sleep until the next host VBlank while the original reset waits.
            branch = f'm->fuel = 0; next = {hex_c(target)}; goto yield;'
        else:
            branch = jump(target)
        code = f'if ({BRANCH[op]}) {{ {branch} }}'
    elif op == 'JMP':
        if mode == 'ind':
            wrapped = (operand & 0xff00) | ((operand + 1) & 255)
            return (f'b = lift_read(m, {hex_c(operand)}, {hex_c(pc)}); '
                    f'next = b | ((uint16_t)lift_read(m, {hex_c(wrapped)}, {hex_c(pc)}) << 8); goto yield;')
        return jump(operand)
    elif op == 'JSR':
        return (f'lift_push(m, &s, {(next_pc - 1) >> 8}); '
                f'lift_push(m, &s, {(next_pc - 1) & 255}); {jump(operand)}')
    elif op in ('RTS', 'RTI'):
        prefix = 'p = (lift_pop(m, &s) | Z_U) & ~0x10; ' if op == 'RTI' else ''
        increment = ' ++next;' if op == 'RTS' else ''
        return f'{prefix}next = lift_pop(m, &s); next |= (uint16_t)lift_pop(m, &s) << 8;{increment} goto resume;'
    elif op in ('LDA', 'LDX', 'LDY'):
        r = REG[op]
        code = f'{r} = {load()};' + store_flags(live & (N | Z), r)
    elif op in ('STA', 'STX', 'STY'):
        code = write(REG[op])
    elif op in ('CMP', 'CPX', 'CPY'):
        r = REG[op]
        code = f'b = {load()};' + store_flags(live & (C | N | Z), f'(uint8_t)({r} - b)', {C: f'({r} >= b)'})
    elif op in ('ADC', 'SBC'):
        factor = 'b' if op == 'ADC' else '(b ^ 255)'
        sign = '~(a ^ b)' if op == 'ADC' else '(a ^ b)'
        extra = {C: '(sum >> 8)', V: f'((({sign} & (a ^ sum)) & 0x80) >> 1)'}
        flags = store_flags(live & (C | N | Z | V), '(uint8_t)sum', extra)
        code = f'b = {load()}; sum = a + {factor} + (p & Z_C);{flags} a = (uint8_t)sum;'
    elif op in ('AND', 'ORA', 'EOR'):
        operator = {'AND': '&', 'ORA': '|', 'EOR': '^'}[op]
        code = f'a {operator}= {load()};' + store_flags(live & (N | Z), 'a')
    elif op == 'BIT':
        live_bit = live & (N | Z | V)
        code = f'b = {load()};'
        if live_bit:
            z = ' | ((a & b) == 0 ? Z_Z : 0)' if (live_bit & Z) else ''
            code += f' p = (p & ~{live_bit}) | (b & {live_bit & (N | V)}){z};'
    elif op in ('ASL', 'LSR', 'ROL', 'ROR'):
        left = op in ('ASL', 'ROL')
        carry = ('(p & Z_C)' if left else '((p & Z_C) << 7)') if op in ('ROL', 'ROR') else '0'
        value = f'(b << 1) | {carry}' if left else f'(b >> 1) | {carry}'
        carry_out = '(b >> 7)' if left else '(b & 1)'
        flags = store_flags(live & (C | N | Z), 't', {C: carry_out})
        code = f'b = {load()}; t = (uint8_t)({value});{flags} {write("t")}'
    elif op in ('INC', 'DEC'):
        operator = '+' if op == 'INC' else '-'
        code = f't = (uint8_t)({load()} {operator} 1);' + store_flags(live & (N | Z), 't') + f' {write("t")}'
    elif op in ('INX', 'INY', 'DEX', 'DEY'):
        r = op[-1].lower()
        operator = '++' if op.startswith('IN') else '--'
        code = f'{operator}{r};' + store_flags(live & (N | Z), r)
    elif op in ('TAX', 'TAY', 'TXA', 'TYA', 'TXS', 'TSX'):
        source, dest = op[1:].lower()
        code = f'{dest} = {source};'
        if dest != 's':
            code += store_flags(live & (N | Z), dest)
    elif op in ('CLC', 'CLD', 'CLI', 'CLV', 'SEC', 'SED', 'SEI'):
        flag = f'Z_{op[-1]}'
        code = f'p &= ~{flag};' if op.startswith('CL') else f'p |= {flag};'
    elif op == 'PHA':
        code = 'lift_push(m, &s, a);'
    elif op == 'PHP':
        code = 'lift_push(m, &s, p | 0x30);'
    elif op == 'PLA':
        code = 'a = lift_pop(m, &s);' + store_flags(live & (N | Z), 'a')
    elif op == 'PLP':
        code = 'p = (lift_pop(m, &s) | Z_U) & ~0x10;'
    elif op == 'NOP':
        code = ';'
    else:
        raise ValueError(f'Unsupported instruction {group}:{pc:04x} {op} {mode}')
    return code if next_pc in local else f'{code} {jump(next_pc)}'


def emit_chunk(path, name, group, base, local):
    flags = flag_liveness(local)
    code = ['/* Generated from the verified PRG0 instruction map. */',
            '#include "lift.h"', '',
            f'uint16_t {name}(Lift *m, uint16_t pc)', '{',
            '    static const void *const entries[] = {']
    code.extend(f'        [{pc - base}] = &&L_{pc:04x},' for pc in local)
    code.extend(['    };', '    const unsigned index = pc - ' + hex_c(base) + ';',
                 '    if (index >= sizeof(entries) / sizeof(entries[0]) || !entries[index]) {',
                 '        m->fault = 1;', '        return pc;', '    }',
                 '    uint8_t a = m->a, x = m->x, y = m->y, s = m->s, p = m->p;',
                 '    uint8_t b __attribute__((unused)), t __attribute__((unused));',
                 '    uint16_t next, sum __attribute__((unused));',
                 '    goto *entries[index];', ''])
    for pc, instruction in local.items():
        code.extend([f'L_{pc:04x}:', '    ' + translate_instruction(group, pc, instruction, local, flags[pc])])
    if any(ins[1] in ('RTS', 'RTI') for ins in local.values()):
        code.extend(['resume:', '    {', f'        const unsigned offset = next - {hex_c(base)};',
                     '        if (next != Z_IDLE && m->fuel && offset < sizeof(entries) / sizeof(entries[0]) && entries[offset]) {',
                     '            --m->fuel;', '            goto *entries[offset];', '        }', '    }'])
    code.extend(['yield:', '    m->a = a;', '    m->x = x;', '    m->y = y;', '    m->s = s;',
                 '    m->p = p;', '    return next;', '}'])
    update_generated(path, '\n'.join(code) + '\n')


def emit_dispatch(path, chunks):
    code = ['/* Native entry points indexed by the active PRG bank and source address. */',
            '#include "lift.h"', '', 'typedef uint16_t (*Chunk)(Lift *, uint16_t);', '']
    code.extend(f'uint16_t {name}(Lift *, uint16_t);' for name in chunks.values())
    code.extend(['', 'static const Chunk chunks[9][16] = {'])
    for group in range(9):
        entries = ', '.join(f'[{index}] = {name}' for (bank, index), name in chunks.items() if bank == group)
        code.append(f'    [{group}] = {{ {entries} }},')
    code.extend(['};', '', 'uint16_t lift_block(Lift *m, unsigned group, uint16_t pc)', '{',
                 '    const unsigned base = group == 8 ? 0x6000 : group == 7 ? 0xc000 : 0x8000;',
                 '    const unsigned index = ((unsigned)pc - base) >> 10;',
                 '    if (index < 16 && chunks[group][index]) return chunks[group][index](m, pc);',
                 '    m->fault = 1;', '    return pc;', '}'])
    update_generated(path, '\n'.join(code) + '\n')


def emit_data(path, prg, palette_path):
    palette = json.loads(palette_path.read_text())
    colors = []
    for rgb in palette:
        red, green, blue = rgb >> 16, (rgb >> 8) & 255, rgb & 255
        colors.append(((red * 7 + 127) // 255) << 1 | ((green * 7 + 127) // 255) << 5
                      | ((blue * 7 + 127) // 255) << 9)
    with path.open('w') as file:
        file.write('#include "lift.h"\n\nconst uint8_t lift_prg[0x20000] = {\n')
        for offset in range(0, len(prg), 16):
            file.write('    ' + ', '.join(f'0x{b:02x}' for b in prg[offset:offset + 16]) + ',\n')
        file.write('};\n\nconst uint16_t lift_colors[64] = {\n')
        for offset in range(0, 64, 8):
            file.write('    ' + ', '.join(hex_c(c) for c in colors[offset:offset + 8]) + ',\n')
        file.write('};\n')


def main():
    project = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('rom', type=Path)
    parser.add_argument('--data', type=Path, default=project / 'data')
    parser.add_argument('--output', type=Path, default=project / 'src' / 'generated')
    args = parser.parse_args()
    image = args.rom.read_bytes()
    if hashlib.sha256(image).hexdigest() != PRG0_SHA256:
        parser.error('Expected The Legend of Zelda (USA), PRG0 with the original iNES header.')
    prg = image[16:]
    regions = read_catalogue(args.data / 'prg0_instructions.json.gz', prg)
    args.output.mkdir(parents=True, exist_ok=True)
    chunks = {}
    for group, instructions in sorted(regions.items()):
        for index in range(16):
            base = ORIGINS[group] + index * CHUNK
            local = {pc: instructions[pc] for pc in sorted(instructions) if base <= pc < base + CHUNK}
            if local:
                name = f'code_{group}_{index:02x}'
                chunks[group, index] = name
                emit_chunk(args.output / (name + '.c'), name, group, base, local)
    emit_dispatch(args.output / 'dispatch.c', chunks)
    emit_data(args.output / 'cart_data.c', prg, args.data / 'nes_reference_palette.json')
    print(f'{sum(map(len, regions.values())):,} native instruction entries in {len(chunks)} chunks')


if __name__ == '__main__':
    main()

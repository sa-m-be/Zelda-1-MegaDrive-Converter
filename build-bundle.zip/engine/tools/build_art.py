#!/usr/bin/env python3
"""Prepare the PRG0 pattern tables in Mega Drive VDP tile format."""

import argparse
from collections import defaultdict
import hashlib
from pathlib import Path

from translate import PRG0_SHA256, update_generated


def pattern_ranges(prg):
    def words(bank, address, count, order):
        offset = bank * 0x4000 + address - 0x8000
        return [int.from_bytes(prg[i:i + 2], order) for i in range(offset, offset + 2 * count, 2)]

    # Title, file menu and overworld/dungeon pattern loaders.
    sources = (
        (1, words(1, 0x8d3b, 2, 'little'), words(1, 0x8d3f, 2, 'big')),
        (2, words(2, 0x8000, 3, 'little'), words(2, 0x8006, 3, 'big')),
        (3, words(3, 0x802c, 2, 'little'), words(3, 0x8038, 2, 'big')),
        (3, words(3, 0x8028, 2, 'little'), words(3, 0x803c, 2, 'big')),
    )
    ranges = defaultdict(list)

    def add(bank, address, size):
        if not 0x8000 <= address < address + size <= 0xc000 or size % 16:
            raise ValueError(f'Unexpected pattern source in bank {bank} at {address:04x}')
        offset = bank * 0x4000 + address - 0x8000
        ranges[bank, offset % 16].append((offset, offset + size))

    for bank, addresses, sizes in sources:
        for address, size in zip(addresses, sizes, strict=True):
            add(bank, address, size)
    dungeon_sizes = words(3, 0x8040, 2, 'big')
    for address_table, size in zip((0x8000, 0x8014), dungeon_sizes, strict=True):
        for address in words(3, address_table, 10, 'little'):
            add(3, address, size)

    merged = []
    for spans in ranges.values():
        first, last = min(spans)
        for start, end in sorted(spans)[1:]:
            if start <= last:
                last = max(last, end)
            else:
                merged.append((first, last))
                first, last = start, end
        merged.append((first, last))
    return sorted(merged)


def tile_rows(pattern, palette):
    for lo, hi in zip(pattern[:8], pattern[8:], strict=True):
        row = 0
        for bit in range(7, -1, -1):
            color = ((lo >> bit) & 1) | (((hi >> bit) & 1) << 1)
            row = (row << 4) | (color + palette * 3 if color else 0)
        yield row


def render_art(prg):
    tiles = [bytes(16)]  # A reset pattern is fully transparent.
    spans = []
    for start, end in pattern_ranges(prg):
        spans.append((start, len(tiles), (end - start) // 16))
        tiles.extend(prg[i:i + 16] for i in range(start, end, 16))
    lines = ['/* Generated from the verified PRG0 pattern tables. */', '#include "vdp_art.h"', '',
             f'const uint16_t vdp_art_span_count = {len(spans)};',
             'const VdpArtSpan vdp_art_spans[] = {']
    lines.extend(f'    {{0x{offset:05x}, {first}, {count}}},' for offset, first, count in spans)
    lines.append('};')
    for palette in range(4):
        lines.extend(('', f'static const uint32_t art_{palette}[][8] __attribute__((aligned(64))) = {{'))
        for tile in tiles:
            rows = ', '.join(f'0x{row:08x}ul' for row in tile_rows(tile, palette))
            lines.append(f'    {{{rows}}},')
        lines.append('};')
    lines.extend(('', 'const uint32_t (*const vdp_art_palettes[4])[8] = {art_0, art_1, art_2, art_3};'))
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('rom', type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parents[1] / 'src/generated/vdp_art.c')
    args = parser.parse_args()
    image = args.rom.read_bytes()
    if hashlib.sha256(image).hexdigest() != PRG0_SHA256:
        parser.error('Expected the verified Zelda PRG0 image.')
    update_generated(args.output, render_art(image[16:]))


if __name__ == '__main__':
    main()

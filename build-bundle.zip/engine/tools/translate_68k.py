#!/usr/bin/env python3
"""Lower the verified PRG0 catalogue to 68000 blocks with a fixed register ABI."""

import argparse
from bisect import bisect_right
from functools import cache
import hashlib
from pathlib import Path

from translate import (BRANCH_READ, C, CNZ_OPS, N, NZ_OPS, ORIGINS, PRG0_SHA256, REG, V, Z,
                       branch_target, flag_usage, hex_c, read_catalogue, update_generated)


ACC, X, Y, SP, P = 'd2', 'd3', 'd4', 'd5', 'd6'
REGISTERS = dict(a=ACC, x=X, y=Y, s=SP)
CCR = {C: 1, Z: 4, N: 8, V: 2, 4: 16, 8: 32}
STATUS_FLAGS = sum(CCR)
OBJECT_WINDOW = 0x3c0  # LIFT_OBJECT_WINDOW in lift_layout.h
BR_INVERSE = dict(BCC='bne', BCS='beq', BEQ='beq', BNE='bne', BMI='beq', BPL='bne', BVC='bne', BVS='beq')
NATIVE_INVERSE = dict(BCC='bcs', BCS='bcc', BEQ='bne', BNE='beq', BMI='bpl', BPL='bmi', BVC='bvs', BVS='bvc')
OPPOSITE = dict(bcs='bcc', bcc='bcs', bne='beq', beq='bne', bpl='bmi', bmi='bpl', bvs='bvc', bvc='bvs')
CCR_PRODUCERS = NZ_OPS | CNZ_OPS | {'ADC', 'SBC'}
FUSED_ACC_ONLY = {'ASL', 'LSR', 'ROL', 'ROR'}
REPEATABLE = {'ASL': ('lsl', ACC), 'LSR': ('lsr', ACC),
              'INX': ('addq', X), 'INY': ('addq', Y), 'DEX': ('subq', X), 'DEY': ('subq', Y)}
MEMORY_WRITES = {'STA', 'STX', 'STY', 'ASL', 'LSR', 'ROL', 'ROR', 'INC', 'DEC'}
DIRECT_HELPERS = {
    (8, 0x6fc1): ('lift_move_positive', 0x6fe7),
    (8, 0x6fe8): ('lift_move_negative', 0x700e),
    (8, 0x7013): ('lift_native_direction_index', 0x701e),
    (8, 0x7a2d): ('lift_collision_center', 0x7a4a),
    (8, 0x7dfb): ('lift_collision_square', 0x7e25),
    (8, 0x7dff): ('lift_collision_box', 0x7e25),
}
IDLE = 0xe45b
SWITCH_DISPATCH = 0xe5e2

# The PRG0 program selects a content module and changes the playfield layout
# through these routines. The upper module stays fixed for the whole game.
MODULE_ENTRIES = {(7, 0xffac): 'lift_select_module', (7, 0xff98): 'lift_set_layout',
                  (1, 0xbfac): 'lift_select_module', (2, 0xbfac): 'lift_select_module',
                  (5, 0xbfac): 'lift_select_module', (5, 0xbf98): 'lift_set_layout'}
NATIVE_BLOCKS = {(7, 0xff68): 0xff95, (7, 0xe4aa): 0xe4b4, (7, 0xe62d): 0xe678,
                 (7, 0xe8d8): 0xe8f6, (5, 0xa433): 0xa442, (5, 0xa442): 0xa4d3,
                 (5, 0xa720): 0xa7f1, (5, 0xaa1b): 0xaabf}
NATIVE_BLOCKS.update({key: key[1] + 0x13 for key in MODULE_ENTRIES})


def platform_function(bank, address):
    if bank == 8 and address in (0xbf98, 0xbfac):
        return MODULE_ENTRIES[5, address]
    return MODULE_ENTRIES.get(static_target(bank, address))


def label(bank, pc):
    return f'prg_{bank}_{pc:04x}'


def addr_imm(addr):
    return '#' + hex_c(addr)


def resolve(regions, bank, pc):
    if pc == IDLE:
        return None
    target = 7 if pc >= 0xc000 else 8 if pc < 0x8000 else bank
    if target in regions and pc in regions[target]:
        return label(target, pc)
    return None


def jump(regions, bank, pc):
    target = resolve(regions, bank, pc)
    if target:
        return [f'jmp {target}']
    if 0x8000 <= pc < 0xc000:
        # The active module already owns a table of 68000 addresses. A known
        # destination can use its slot without decoding an original address.
        displacement = ((pc << 2) + 0x8000) % 0x10000 - 0x8000
        return [f'move.w {addr_imm(pc)},d0', 'subq.l #1,d7', 'bcs.b 7f',
                f'movea.l {displacement}(a4),a0', 'jmp (a0)',
                '7:', 'moveq #0,d7', 'jmp lift_native_pause']
    return [f'move.w {addr_imm(pc)},d0', 'jmp lift_native_dispatch']


def syscall(name):
    return [f'jsr {name}']


def c_adapter(name, arguments=('a2',)):
    stores = [f'move.l {reg},-(sp)' for reg in ('a1', *arguments)]
    return stores + [f'jsr {name}', f'lea {4 * len(arguments)}(sp),sp', 'movea.l (sp)+,a1']


def read_address(mode, operand, pc):
    if mode == 'abs' and operand == 0x2002:
        if pc == 0x8521:
            return syscall('lift_playfield_ready')
        return syscall('lift_native_ppustatus')
    if mode == 'abs' and operand == 0x2007:
        return c_adapter('lift_screen_readback') + ['move.b d0,d1']
    if mode == 'indy':
        return compute_addr(mode, operand) + syscall('lift_read_data')
    raise ValueError(f'Unmapped data read at {pc:04x} from {mode} {operand:04x}')


def direct_ea(mode, operand, read):
    """Return setup and a 68000 effective address where the 6502 range stays mapped."""
    if mode in ('zp', 'zpx', 'zpy'):
        if mode == 'zp':
            return [], f'{operand}(a2)'
        index = X if mode == 'zpx' else Y
        if not operand:
            return [], f'0(a2,{index}.w)'
        return [f'move.w {index},d0', f'addi.b {addr_imm(operand)},d0'], '0(a2,d0.w)'
    if mode not in ('abs', 'absx', 'absy'):
        return None
    index = None if mode == 'abs' else X if mode == 'absx' else Y
    high = operand + (255 if index else 0)
    if high < 0x2000 and (operand & 0xf800) == (high & 0xf800):
        base, offset = 'a2', operand & 0x7ff
    elif read and operand >= 0xc000 and high <= 0xffff:
        base, offset = 'a5', operand & 0x3fff
    elif read and operand >= 0x8000 and high < 0xc000:
        base, offset = 'a3', operand & 0x3fff
    elif read and operand >= 0x6000 and high < 0x8000:
        base, offset = 'a2', 2048 + (operand & 0x1fff)
    else:
        return None
    if not index:
        return [], f'{offset}({base})'
    if base == 'a2':
        for anchor, address in (('a1', OBJECT_WINDOW), ('a6', 0x100)):
            if -128 <= offset - address < 128:
                return [], f'{offset - address}({anchor},{index}.w)'
    if offset < 128:
        return [], f'{offset}({base},{index}.w)'
    return [f'lea {offset}({base}),a0'], f'0(a0,{index}.w)'


def read_pointer(operand):
    if operand & 1:
        return [f'move.b {(operand + 1) & 255}(a2),d0', 'lsl.w #8,d0', f'move.b {operand}(a2),d0']
    return [f'move.w {operand}(a2),d0', 'ror.w #8,d0']


def compute_addr(mode, operand):
    if mode == 'indy':
        return read_pointer(operand) + [f'add.w {Y},d0']
    code = [f'move.w {addr_imm(operand)},d0']
    if mode in ('absx', 'absy'):
        code.append(f'add.w {X if mode == "absx" else Y},d0')
    return code


def read_op(mode, operand, destination, pc):
    if mode == 'imm':
        op = 'moveq' if operand < 128 else 'move.b'
        return [f'{op} {addr_imm(operand)},{destination}']
    if mode == 'acc':
        return [f'move.b {ACC},{destination}']
    ea = direct_ea(mode, operand, True)
    if ea:
        setup, source = ea
        return setup + [f'move.b {source},{destination}']
    return read_address(mode, operand, pc) + [f'move.b d1,{destination}']


def audio_event(register, source):
    code = [f'move.b {source},LIFT_APU+{register}(a2)',
            f'addq.b #1,LIFT_APU_WRITES+{register}(a2)']
    if register == 0x15:
        code += [f'and.b {source},LIFT_APU_RELOADED(a2)', f'move.b {source},d0',
                 'not.b d0', 'andi.b #15,d0', 'or.b d0,LIFT_APU_CLEARED(a2)']
    elif register < 16 and register & 3 == 3:
        code += [f'moveq #{1 << (register >> 2)},d0', 'and.b LIFT_APU+0x15(a2),d0',
                 'or.b d0,LIFT_APU_RELOADED(a2)']
    return code


def guard_stack_write(mode, operand):
    """Forget native links if a guest store can touch the return byte area."""
    if mode not in ('abs', 'absx', 'absy') or operand >= 0x2000:
        return []
    offset = operand & 0x7ff
    high = offset + (0 if mode == 'abs' else 255)
    if high < 0x100 or offset >= 0x200:
        return []
    clear = ['movea.l LIFT_RESUME_STACK(a2),sp']
    if mode == 'abs':
        return [f'cmpi.b #{offset & 255},{SP}', 'bcc.b 9f', *clear, '9:']
    return compute_addr(mode, offset) + ['cmpi.w #0x100,d0', 'bcs.b 9f',
                                          'cmpi.w #0x200,d0', 'bcc.b 9f',
                                          f'cmp.b d0,{SP}', 'bcc.b 9f', *clear, '9:']


def write_op(mode, operand, source, bank, next_pc):
    if mode == 'acc':
        return [f'move.b {source},{ACC}']
    ea = direct_ea(mode, operand, False)
    if ea:
        setup, destination = ea
        return guard_stack_write(mode, operand) + setup + [f'move.b {source},{destination}']
    if mode == 'abs' and operand == 0x2007:
        return ([] if source == 'd1' else [f'move.b {source},d1']) + syscall('lift_native_ppudata')
    if mode == 'abs' and operand == 0x2001:
        return [f'move.b {source},LIFT_PPU_OPEN_BUS(a2)', f'move.b {source},LIFT_MASK(a2)']
    ppu = {0x2000: 'lift_native_ppuctrl', 0x2005: 'lift_native_ppuscroll', 0x2006: 'lift_native_ppuaddr'}
    if mode == 'abs' and operand in ppu:
        return ([] if source == 'd1' else [f'move.b {source},d1']) + syscall(ppu[operand])
    if mode == 'abs' and (0x4000 <= operand <= 0x4013 or operand in (0x4015, 0x4017)):
        return audio_event(operand - 0x4000, source)
    value = [] if source == 'd1' else [f'move.b {source},d1']
    if mode in ('abs', 'absx', 'absy') and 0x6000 <= operand <= (0x7fff if mode == 'abs' else 0x7f00):
        return compute_addr(mode, operand - 0x6000) + value + syscall('lift_store_save')
    if mode == 'indy':
        return compute_addr(mode, operand) + value + syscall('lift_store_data')
    raise ValueError(f'Unmapped data write at {bank}:{next_pc:04x} to {mode} {operand:04x}')


def capture_flags(flags, invert_carry=False):
    if not flags:
        return []
    mask = sum(CCR[bit] for bit in (C, V, Z, N) if bit & flags)
    code = ['move.w sr,d0', f'andi.b #{mask},d0']
    if invert_carry and mask & 1:
        code.append('eori.b #1,d0')
    return code + [f'andi.b #{255 ^ mask},{P}', f'or.b d0,{P}']


def capture_branch_edge(flags, predicate, taken, producer):
    """Materialize only the flags read on this edge; the branch proves one bit."""
    bit = BRANCH_READ[predicate]
    true_bit = (predicate in ('BCS', 'BEQ', 'BMI', 'BVS')) == taken
    known = {bit: true_bit}
    if bit == Z and true_bit:
        known[N] = False
        if producer in ('CMP', 'CPX', 'CPY'):
            known[C] = True
    if bit == N and true_bit:
        known[Z] = False
    unknown = flags & ~sum(known)
    code = capture_flags(unknown, producer in ('CMP', 'CPX', 'CPY', 'SBC'))
    set_bits = sum(CCR[flag] for flag, value in known.items() if flags & flag and value)
    clear_bits = sum(CCR[flag] for flag, value in known.items() if flags & flag and not value)
    if clear_bits:
        code.append(f'andi.b #{255 ^ clear_bits},{P}')
    if set_bits:
        code.append(f'ori.b #{set_bits},{P}')
    return code


def push(value, linked=False):
    code = [f'move.b {value},0(a6,{SP}.w)', f'subq.b #1,{SP}']
    if linked:
        code += ['bcc.b 9f', 'movea.l LIFT_RESUME_STACK(a2),sp', '9:']
    return code


def pop(destination, linked=False):
    code = []
    if linked:
        code += [f'cmp.w (sp),{SP}', 'bcs.b 9f', 'movea.l LIFT_RESUME_STACK(a2),sp', '9:']
    return code + [f'addq.b #1,{SP}', f'move.b 0(a6,{SP}.w),{destination}']


def push_return(continuation):
    address = continuation - 1
    return push(addr_imm(address >> 8)) + push(addr_imm(address & 255))


def record_return(continuation):
    address = continuation - 1
    return [f'move.b #{address >> 8},0(a6,{SP}.w)', f'move.w {SP},d0', 'subq.b #1,d0',
            f'move.b #{address & 255},0(a6,d0.w)']


def linked_call(regions, bank, pc, operand, continuation):
    host_link = f'.Lreturn_{bank}_{pc:04x}'
    code = push_return(continuation) + [
        f'cmpi.b #0xfe,{SP}', 'bcc.b 8f',
        f'pea {host_link}', f'move.w {SP},-(sp)', 'bra.b 9f',
        '8:', 'movea.l LIFT_RESUME_STACK(a2),sp', '9:']
    if operand <= pc and resolve(regions, bank, operand) == label(bank, operand):
        code += take_budget(operand, 'bne.b 1f') + ['1:']
    code += jump(regions, bank, operand) + [host_link + ':']
    if bank < 7:
        code += [f'cmpi.b #{bank},LIFT_LOW(a2)', 'beq.b 9f',
                 f'move.w {addr_imm(continuation)},d0', 'jmp lift_native_dispatch', '9:']
    return code


def restore_flags(linked):
    return ['moveq #0,d0'] + pop('d0', linked) + ['lea lift_flags_in,a0', f'move.b 0(a0,d0.w),{P}']


def take_budget(target, branch_ok):
    return ['subq.l #1,d7', branch_ok,
            f'move.w {addr_imm(target)},d0', 'jmp lift_native_pause']


def checkpoint(target, native_target):
    return ['subq.l #1,d7', f'bcc.w {native_target}', 'moveq #0,d7',
            f'move.w {addr_imm(target)},d0', 'jmp lift_native_pause']


def branch(regions, bank, pc, op, operand, native=False, invert_carry=False, near=False, bounded=False,
           local_target=None, edges=((), ())):
    target = branch_target(pc, operand)
    if native:
        predicate = NATIVE_INVERSE[op]
        if invert_carry and op in ('BCS', 'BCC'):
            predicate = 'bcc' if predicate == 'bcs' else 'bcs'
        code = []
    else:
        code = [f'btst #{CCR[BRANCH_READ[op]].bit_length() - 1},{P}']
        predicate = BR_INVERSE[op]
    taken, fallthrough = edges
    if local_target and not taken and (target > pc or bounded):
        return code + [f'{OPPOSITE[predicate]}.w {local_target}', *fallthrough]
    sleep = bank == 7 and pc in (0xff5f, 0xff66)
    if near and not sleep and not taken and (target > pc or bounded):
        return code + [f'{OPPOSITE[predicate]}.w {label(bank, target)}', *fallthrough]
    code += [f'{predicate}.b 2f', *taken]
    if local_target:
        if target <= pc and not bounded:
            code.extend(checkpoint(target, local_target))
        else:
            code.append(f'bra.w {local_target}')
    elif sleep:
        code += ['moveq #0,d7', f'move.w {addr_imm(target)},d0', 'jmp lift_native_pause']
    elif near and (target > pc or bounded):
        code.append(f'bra.w {label(bank, target)}')
    elif near:
        code += take_budget(target, f'bne.w {label(bank, target)}')
    elif target <= pc and resolve(regions, bank, target):
        code += take_budget(target, 'bne.b 1f') + ['1:'] + jump(regions, bank, target)
    else:
        code += jump(regions, bank, target)
    return code + ['2:', *fallthrough]


def lower(regions, bank, pc, ins, live, near=False, bounded=False, carry=None, native_test=0, linked=True):
    raw, op, mode = ins
    operand = int.from_bytes(raw[1:], 'little')
    next_pc = (pc + len(raw)) & 0xffff
    written = live & flag_usage(op)[1]

    if op in BRANCH_READ:
        return branch(regions, bank, pc, op, operand, near=near, bounded=bounded)
    if op in ('JMP', 'JSR'):
        if mode == 'ind':
            raise ValueError(f'Unmapped indirect jump at {bank}:{pc:04x}')
        platform_entry = platform_function(bank, operand)
        if platform_entry:
            if op == 'JSR':
                return record_return(next_pc) + syscall(platform_entry)
            return syscall(platform_entry) + ['jmp lift_native_return']
        if op == 'JSR' and linked and next_pc in regions[bank]:
            return linked_call(regions, bank, pc, operand, next_pc)
        code = push_return(next_pc) if op == 'JSR' else []
        if operand <= pc and resolve(regions, bank, operand) == label(bank, operand):
            code += take_budget(operand, 'bne.b 1f') + ['1:']
        return code + jump(regions, bank, operand)
    if op in ('RTS', 'RTI'):
        if op == 'RTS':
            return ['jmp lift_native_return']
        if (bank, pc) == (7, 0xe57f):
            return ['jmp lift_finish_step']
        raise ValueError(f'Unmapped frame exit at {bank}:{pc:04x}')

    if op in ('LDA', 'LDX', 'LDY'):
        reg = REGISTERS[REG[op]]
        return read_op(mode, operand, reg, pc) + capture_flags(written)
    if op in ('STA', 'STX', 'STY'):
        return write_op(mode, operand, REGISTERS[REG[op]], bank, next_pc)
    if op in ('CMP', 'CPX', 'CPY'):
        reg = REGISTERS[REG[op]]
        ea = direct_ea(mode, operand, True)
        if mode == 'imm':
            code = [f'cmpi.b {addr_imm(operand)},{reg}']
        elif ea:
            setup, source = ea
            code = setup + [f'cmp.b {source},{reg}']
        else:
            code = read_op(mode, operand, 'd1', pc) + [f'cmp.b d1,{reg}']
        return code + capture_flags(written, True)
    if op in ('ADC', 'SBC'):
        if carry == (1 if op == 'SBC' else 0):
            operator = 'sub' if op == 'SBC' else 'add'
            ea = direct_ea(mode, operand, True)
            if mode == 'imm':
                code = [f'{operator}i.b {addr_imm(operand)},{ACC}']
            elif ea:
                setup, source = ea
                code = setup + [f'{operator}.b {source},{ACC}']
            else:
                code = read_op(mode, operand, 'd1', pc) + [f'{operator}.b d1,{ACC}']
            return code + capture_flags(written, op == 'SBC')
        code = read_op(mode, operand, 'd1', pc)
        if op == 'SBC':
            code += ['moveq #1,d0', f'eor.b {P},d0']
        else:
            code.append(f'move.b {P},d0')
        # ADDX/SUBX update the old Z cumulatively. Seed it before each 6502 op.
        code.append('lsr.b #1,d0')
        if (written | native_test) & Z:
            code.append('ori.b #4,ccr')
        code.append(f'{"subx" if op == "SBC" else "addx"}.b d1,{ACC}')
        return code + capture_flags(written, op == 'SBC')
    if op in ('AND', 'ORA', 'EOR'):
        name = 'or' if op == 'ORA' else op.lower()
        if mode == 'imm':
            code = [f'{name}i.b {addr_imm(operand)},{ACC}']
        else:
            ea = direct_ea(mode, operand, True) if op != 'EOR' else None
            if ea:
                setup, source = ea
                code = setup + [f'{name}.b {source},{ACC}']
            else:
                code = read_op(mode, operand, 'd1', pc) + [f'{name}.b d1,{ACC}']
        return code + capture_flags(written)
    if op == 'BIT':
        code = read_op(mode, operand, 'd1', pc)
        if written & (N | V):
            mask = (8 if written & N else 0) | (2 if written & V else 0)
            code += ['moveq #0,d0', 'move.b d1,d0', 'lsr.w #4,d0',
                     'andi.b #8,d0'] if written & N else ['moveq #0,d0']
            if written & V:
                code += ['btst #6,d1', 'beq.b 1f', 'ori.b #2,d0', '1:']
            code += [f'andi.b #{255 ^ mask},{P}', f'or.b d0,{P}']
        if written & Z:
            code += [f'and.b {ACC},d1'] + capture_flags(Z)
        return code
    if op in ('ASL', 'LSR', 'ROL', 'ROR', 'INC', 'DEC'):
        if op in ('INC', 'DEC'):
            ea = direct_ea(mode, operand, False)
            if ea:
                setup, destination = ea
                code = setup + [f'{"addq" if op == "INC" else "subq"}.b #1,{destination}']
                return guard_stack_write(mode, operand) + code + capture_flags(written)
        reg = ACC if mode == 'acc' else 'd1'
        code = [] if mode == 'acc' else read_op(mode, operand, reg, pc)
        if op in ('ROL', 'ROR'):
            code += [f'move.b {P},d0', 'lsr.b #1,d0']
        shifts = {'ASL': 'lsl.b #1,', 'LSR': 'lsr.b #1,', 'ROL': 'roxl.b #1,', 'ROR': 'roxr.b #1,',
                  'INC': 'addq.b #1,', 'DEC': 'subq.b #1,'}
        operation = f'add.b {reg},{reg}' if op == 'ASL' else shifts[op] + reg
        code += [operation] + capture_flags(written)
        if mode != 'acc':
            code += write_op(mode, operand, reg, bank, next_pc)
        return code
    if op in ('INX', 'INY', 'DEX', 'DEY'):
        reg = REGISTERS[op[-1].lower()]
        return [f'{"addq" if op.startswith("IN") else "subq"}.b #1,{reg}'] + capture_flags(written)
    if op in ('TAX', 'TAY', 'TXA', 'TYA', 'TXS', 'TSX'):
        source, dest = map(REGISTERS.get, op[1:].lower())
        return [f'move.b {source},{dest}'] + capture_flags(written)
    if op in ('CLC', 'SEC', 'CLV', 'CLD', 'SED', 'SEI', 'CLI'):
        if not written:
            return []
        flag = CCR[dict(C=C, V=V, D=8, I=4)[op[-1]]]
        return [f'ori.b #{flag},{P}'] if op.startswith('SE') else [f'andi.b #{255 ^ flag},{P}']
    if op == 'PHA':
        return push(ACC, linked)
    if op == 'PHP':
        return ['lea lift_flags_out,a0', f'move.b 0(a0,{P}.w),d0', 'ori.b #16,d0'] + push('d0', linked)
    if op == 'PLA':
        return pop(ACC, linked) + capture_flags(written)
    if op == 'PLP':
        return restore_flags(linked)
    if op == 'NOP':
        return []
    raise ValueError(f'Unsupported 68000 lowering at {bank}:{pc:04x}: {op} {mode}')


def static_target(bank, address):
    return (7 if address >= 0xc000 else 8 if address < 0x8000 else bank), address


def native_routines(regions):
    """Find closed routines that can return through the 68000 stack.

    Every edge must preserve the depth of explicit stack reads and writes.
    Loops with a stable depth can resume at their ordinary entry labels when
    a frame reaches the execution limit.
    """
    checked = {}
    stack_use = {}

    def check(bank, start):
        key = bank, start
        if key in checked:
            return checked[key]
        checked[key] = None  # Recursion stays on the normal guest stack.
        local = regions[bank]
        depths = {}
        pending = [(start, 0)]
        peak = 0

        while pending:
            pc, depth = pending.pop()
            if pc in depths:
                if depth != depths[pc]:
                    return None
                continue
            if pc not in local or pc == IDLE or len(depths) >= 384 or not 0 <= depth <= 16:
                return None
            # Keep the full semantic replacement on all entry paths.
            if fast_entry(bank, pc) and (bank, pc) not in DIRECT_HELPERS:
                return None
            depths[pc] = depth
            peak = max(peak, depth)
            raw, op, mode = local[pc]
            target = int.from_bytes(raw[1:], 'little')
            following = pc + len(raw)
            if op == 'RTS':
                if depth != 0:
                    return None
                continue
            if op in ('RTI', 'TXS'):
                return None
            if op in MEMORY_WRITES and mode not in ('acc', 'zp', 'zpx', 'zpy'):
                # A write through an opaque pointer can modify return bytes.
                if mode not in ('abs', 'absx', 'absy'):
                    return None
                extent = 255 if mode != 'abs' else 0
                if target + extent >= 0x8000:
                    return None
                if target < 0x2000 and (target & 0x7ff) <= 0x1ff and (target & 0x7ff) + extent >= 0x100:
                    return None
            if op in ('PHA', 'PHP'):
                depth += 1
            elif op in ('PLA', 'PLP'):
                depth -= 1
            if op == 'JMP':
                if mode != 'abs':
                    return None
                pending.append((target, depth))
            elif op == 'JSR':
                callee, address = static_target(bank, target)
                if check(callee, address) is None:
                    return None
                peak = max(peak, depth + 2 + stack_use[callee, address])
                if peak > 32:
                    return None
                pending.append((following, depth))
            elif op in BRANCH_READ:
                pending.extend(((following, depth), (branch_target(pc, target), depth)))
            else:
                pending.append((following, depth))

        checked[key] = set(depths)
        stack_use[key] = peak
        return checked[key]

    for bank, local in regions.items():
        for pc, (raw, op, _) in local.items():
            if op == 'JSR' and pc + len(raw) in local:
                check(*static_target(bank, int.from_bytes(raw[1:], 'little')))
    return {key: nodes for key, nodes in checked.items() if nodes}


def flag_dependencies(regions, routines):
    """Propagate the flags observed at proven call returns to the callee."""

    def analyse(bank, nodes, exit_flags):
        local = regions[bank]
        actions = []
        for pc in sorted(nodes, reverse=True):
            raw, op, mode = local[pc]
            operand = int.from_bytes(raw[1:], 'little')
            following = pc + len(raw)
            read, written = flag_usage(op)
            callee = None
            if op == 'JSR' and following in nodes and static_target(bank, operand) in routines:
                callee = static_target(bank, operand)
            if op in BRANCH_READ:
                targets = following, branch_target(pc, operand)
            elif callee:
                targets = (following,)
            elif op in ('JMP', 'JSR'):
                targets = (operand if mode != 'ind' else None,)
            elif op in ('RTI', 'RTS'):
                targets = ()
            else:
                targets = (following,)
            actions.append((pc, targets, callee, read, written))

        incoming = dict.fromkeys(nodes, 0)
        outgoing = dict.fromkeys(nodes, 0)
        while True:
            changed = False
            for pc, targets, callee, read, written in actions:
                live = 0 if targets else exit_flags
                for target in targets:
                    live |= incoming.get(target, STATUS_FLAGS)
                outgoing[pc] = live
                required = variant(*callee, live)[0] if callee else (read | (live & ~written)) & STATUS_FLAGS
                if required != incoming[pc]:
                    incoming[pc] = required
                    changed = True
            if not changed:
                return incoming, outgoing

    @cache
    def variant(bank, pc, wanted):
        incoming, outgoing = analyse(bank, routines[bank, pc], wanted)
        return incoming[pc], incoming, outgoing

    return analyse, variant


def direct_label(bank, start, wanted, pc):
    return f'fast_{bank}_{start:04x}_{wanted:02x}_{pc:04x}'


def call_direct(bank, operand, continuation, wanted, requested):
    new_bank, address = static_target(bank, operand)
    wanted = STATUS_FLAGS if (new_bank, address) in DIRECT_HELPERS else wanted
    requested.add((new_bank, address, wanted))
    return push_return(continuation) + [f'jsr {direct_label(new_bank, address, wanted, address)}']


def repeat_spans(local, blocked):
    """Combine byte shifts or index steps along a straight fallthrough."""
    spans = {}
    consumed = set()
    for pc in sorted(local):
        _, op, mode = local[pc]
        if pc in consumed or op not in REPEATABLE or (op in ('ASL', 'LSR') and mode != 'acc'):
            continue
        end = pc
        while end + 1 not in blocked and end - pc < 7 and local.get(end + 1) == local[pc]:
            end += 1
        if end != pc:
            spans[pc] = end
            consumed.update(range(pc + 1, end + 1))
    return spans, consumed


def lower_repeat(op, count, live):
    operator, register = REPEATABLE[op]
    return [f'{operator}.b #{count},{register}'] + capture_flags(live & flag_usage(op)[1])


def emit_native_routine(regions, bank, start, wanted, nodes, incoming, live, requested):
    local = regions[bank]
    if (bank, start) in DIRECT_HELPERS:
        name, _ = DIRECT_HELPERS[bank, start]
        return [f'{direct_label(bank, start, wanted, start)}:', f'jsr {name}', f'addq.b #2,{SP}', 'rts']

    def destination(pc):
        return direct_label(bank, start, wanted, pc)

    # Inside a proven routine, only real control-flow edges can enter its
    # private copy. The catalogue entries themselves remain addressable.
    entries = {start}
    for pc in nodes:
        raw, op, _ = local[pc]
        if op in BRANCH_READ:
            entries.add(branch_target(pc, raw[1]))
        if op == 'JMP':
            entries.add(int.from_bytes(raw[1:], 'little'))
    body = {pc: local[pc] for pc in nodes}
    bounded = bounded_loops(body)
    spans, skipped = repeat_spans(body, entries)
    fused = {pc: following for pc, following in fusion_points(body).items()
             if pc in nodes and following in nodes - entries}
    carry_setup = {'CLC': (0, 'ADC'), 'SEC': (1, 'SBC')}
    carries = {}
    for pc in nodes:
        raw, op, _ = local[pc]
        following = pc + len(raw)
        if op in carry_setup and following in nodes - entries:
            value, next_op = carry_setup[op]
            if local[following][1] == next_op:
                carries[following] = value
    moved = set(fused.values())
    lines = []
    for pc in sorted(nodes - moved - skipped):
        lines.append(f'{destination(pc)}:')
        first = pc
        pc = spans.get(pc, pc)
        entry = local[pc]
        raw, op, _ = entry
        operand = int.from_bytes(raw[1:], 'little')
        following = pc + len(raw)
        test, edges = fusion_flags(local, pc, incoming) if pc in fused else (0, ((), ()))
        written = 0 if test else live[pc]
        if op == 'RTS':
            lines.extend((f'addq.b #2,{SP}', 'rts'))
            continue
        if op == 'JMP':
            if operand <= pc:
                lines.extend(checkpoint(operand, destination(operand)))
            else:
                lines.append(f'bra.w {destination(operand)}')
            continue
        if first != pc:
            lines.extend(lower_repeat(op, pc - first + 1, written))
        elif op == 'JSR':
            lines.extend(call_direct(bank, operand, following, live[pc], requested))
        elif op in BRANCH_READ:
            lines.extend(branch(regions, bank, pc, op, operand,
                                local_target=destination(branch_target(pc, operand)), bounded=pc in bounded))
        elif op not in carry_setup or following not in carries:
            lines.extend(lower(regions, bank, pc, entry, written, carry=carries.get(pc),
                               native_test=test, linked=False))
        if pc in fused:
            ins, control, _ = local[following]
            lines.extend(branch(regions, bank, following, control, ins[1], native=True,
                                invert_carry=op in ('CMP', 'CPX', 'CPY', 'SBC'),
                                local_target=destination(branch_target(following, ins[1])),
                                bounded=following in bounded, edges=edges))
    return lines


def fusion_points(local):
    points = {}
    for pc, (raw, op, mode) in local.items():
        if op not in CCR_PRODUCERS or (op in FUSED_ACC_ONLY and mode != 'acc'):
            continue
        if op in ('INC', 'DEC') and direct_ea(mode, int.from_bytes(raw[1:], 'little'), False) is None:
            continue
        following = pc + len(raw)
        _, control, _ = local.get(following, (None, None, None))
        written = flag_usage(op)[1]
        if control in BRANCH_READ and written & BRANCH_READ[control]:
            points[pc] = following
    return points


def fusion_flags(local, pc, incoming):
    raw, producer, _ = local[pc]
    branch_pc = pc + len(raw)
    branch_raw, predicate, _ = local[branch_pc]
    destinations = branch_target(branch_pc, branch_raw[1]), branch_pc + len(branch_raw)
    written = flag_usage(producer)[1]
    taken, fallthrough = (incoming.get(target, STATUS_FLAGS) & written for target in destinations)
    test = BRANCH_READ[predicate] | taken | fallthrough
    return test, (capture_branch_edge(taken, predicate, True, producer),
                  capture_branch_edge(fallthrough, predicate, False, producer))


def bounded_loops(local):
    """Recognize closed 8-bit counter loops that can run at most 256 times."""
    safe = set()
    end_at = {address + len(raw): (op, mode) for address, (raw, op, mode) in local.items()}
    writes = {'x': {'LDX', 'TAX', 'TSX', 'DEX', 'INX'}, 'y': {'LDY', 'TAY', 'DEY', 'INY'}}
    for pc, (raw, op, _) in local.items():
        if op not in ('BNE', 'BPL', 'BMI'):
            continue
        target = branch_target(pc, raw[1])
        previous, mode = end_at.get(pc, (None, None))
        if previous in ('DEX', 'INX', 'DEY', 'INY') or (op == 'BNE' and previous in ('CPX', 'CPY') and mode == 'imm'):
            reg = previous[-1].lower()
        else:
            continue
        if target >= pc:
            continue
        effects = []
        branches = []
        address = target
        while address < pc:
            body, operation, _ = local.get(address, (None, None, None))
            if body is None or operation in ('JMP', 'JSR', 'RTS', 'RTI'):
                break
            if operation in BRANCH_READ:
                branches.append((address, branch_target(address, body[1])))
            if operation in writes[reg]:
                effects.append((address, operation))
            address += len(body)
        if address != pc or len(effects) != 1:
            continue
        step, operation = effects[0]
        if operation[:2] in ('DE', 'IN') and all(dst >= pc + len(raw)
                                                or (src < dst <= step if src < step else src < dst < pc)
                                                for src, dst in branches):
            safe.add(pc)
    return safe


CHR_ENTRY = {(1, 0x8d87): 0x8db0, (2, 0x8052): 0x807b, (3, 0x80ee): 0x8117}


def fast_entry(bank, pc):
    if (bank, pc) == (7, IDLE):
        return [f'move.w {addr_imm(IDLE)},d0', 'jmp lift_native_pause']
    if (bank, pc) == (7, 0xe62d):
        return ['jmp lift_native_pads']
    if (bank, pc) == (7, 0xe4aa):
        return c_adapter('lift_snapshot_sprites') + ['moveq #2,d2', 'andi.b #243,d6', 'jmp prg_7_e4b4']
    if (bank, pc) == (8, 0x6e1d):
        return ['jmp lift_native_hide_objects']
    if (bank, pc) == (8, 0x6d00):
        return ['jmp lift_native_copy_hud']
    if (bank, pc) == (8, 0x7885):
        return ['jmp lift_native_oam_pack']
    if (bank, pc) == (8, 0x77e1):
        return ['jmp lift_actor_sprite']
    if (bank, pc) in DIRECT_HELPERS:
        name, continuation = DIRECT_HELPERS[bank, pc]
        return [f'jsr {name}', f'jmp {label(bank, continuation)}']
    if (bank, pc) == (8, 0x79d0):
        return ['jsr lift_skip_idle_weapons', 'tst.b d0', 'beq.b 8f', 'jmp prg_8_79fd', '8:']
    if (bank, pc) == (8, 0x7aa7):
        return ['jmp lift_probe_link_contact']
    if (bank, pc) == (8, 0x7dcb):
        return ['jmp lift_probe_weapon_square']
    if (bank, pc) == (8, 0x7dd1):
        return ['jmp lift_probe_weapon_center']
    if (bank, pc) == (7, 0xe530):
        return ['cmp.b (a2),d3', 'bls.b 8f', 'jmp lift_native_count_timers', '8:']
    if (bank, pc) == (7, 0xe542):
        return ['jmp lift_native_random']
    if (bank, pc) == (7, 0xf08d):
        return ['tst.b 15(a2)', 'beq.b 8f', 'cmpi.b #32,d3', 'bcc.b 8f', 'cmpi.b #32,d5', 'bcs.b 8f',
                'jsr lift_advance_actor', 'jmp prg_7_f0c0', '8:']
    if (bank, pc) == (8, 0x6e6e):
        return ['jmp lift_native_decimal']
    if (bank, pc) == (6, 0xa0ce):
        return ['jsr lift_native_ppu_run', 'tst.l d0', 'bmi.b 8f', 'move.b d0,d2', 'lsr.w #8,d0',
                'move.b d0,d4', 'moveq #0,d3', 'andi.b #247,d6', 'ori.b #4,d6', 'jmp prg_6_a0d9', '8:']
    if (bank, pc) == (6, 0x80d7):
        return c_adapter('lift_copy_sram_range') + ['tst.l d0', 'bmi.b 8f', 'move.b d0,d2', 'moveq #0,d4',
                                                   'ori.b #1,d6', 'jmp prg_6_80e9', '8:']
    if (bank, pc) == (2, 0xa307):
        return c_adapter('lift_save_checksum') + ['tst.l d0', 'bmi.b 8f',
                'move.b d0,d2', 'lsr.w #8,d0', 'andi.b #240,d6', 'or.b d0,d6', 'moveq #0,d4'] + (
                    push('#0xa3') + push('#0x4e') + ['addq.b #2,d5', 'jmp prg_2_a35c', '8:'])
    if (bank, pc) == (2, 0xa35d):
        return c_adapter('lift_clear_save') + ['tst.l d0', 'beq.b 8f',
                'move.b #255,d2', 'moveq #0,d4', 'andi.b #251,d6', 'ori.b #8,d6', 'jmp prg_2_a38d', '8:']
    if (bank, pc) == (5, 0xaabf):
        return ['jmp lift_native_find_metatile']
    if (bank, pc) == (5, 0xaa1b):
        return c_adapter('lift_decode_overworld') + ['move.b d0,d3', 'moveq #16,d2',
                'moveq #0,d4', 'andi.b #240,d6', 'ori.b #5,d6', 'jmp lift_native_return']
    if (bank, pc) == (5, 0xa442):
        return c_adapter('lift_draw_dungeon_walls') + ['moveq #0x66,d2', 'moveq #24,d3',
                'moveq #0,d4', 'andi.b #240,d6', 'ori.b #5,d6', 'jmp lift_native_return']
    if (bank, pc) == (5, 0xa720):
        return c_adapter('lift_decode_dungeon') + ['move.b d0,d3', 'moveq #12,d2',
                'moveq #0,d4', 'andi.b #240,d6', 'ori.b #7,d6', 'jmp lift_native_return']
    if (bank, pc) == (7, 0xe8d8):
        return ['moveq #5,d2', 'jsr lift_select_module'] + c_adapter('lift_clear_room_map') + [
                'moveq #0x67,d2', 'moveq #0,d4', 'andi.b #240,d6', 'ori.b #5,d6', 'jmp lift_native_return']
    if (bank, pc) == (5, 0x8521):
        return ['cmpi.b #7,18(a2)', 'bne.b 8f', 'jmp lift_room_raster', '8:']
    if (bank, pc) == (5, 0x852b):
        # The old sprite-zero delay only advances the NES raster.
        return ['move.b #255,d3', 'move.b #255,d4', f'andi.b #251,{P}', f'ori.b #8,{P}',
                'jmp prg_5_853e']
    if (bank, pc) == (7, 0xff68):
        return ['jsr lift_prepare_modules', 'jmp prg_7_e440']
    if (bank, pc) in MODULE_ENTRIES:
        return syscall(MODULE_ENTRIES[bank, pc]) + ['jmp lift_native_return']
    if (bank, pc) == (7, 0xe5bc):
        return ['cmpi.b #4,d3', 'bne.b 8f', 'tst.b d4', 'bne.b 8f'] + c_adapter('lift_ppu_fill_table', ('d2', 'a2')) + [
            'tst.l d0', 'beq.b 8f', 'moveq #0,d3', 'andi.b #247,d6', 'ori.b #4,d6', 'jmp prg_7_e5c5', '8:']
    if (bank, pc) == (1, 0x8d00):
        return c_adapter('lift_copy_common_code') + ['moveq #0,d2',
                'moveq #0,d4', 'andi.b #240,d6', 'ori.b #5,d6', 'jmp prg_1_8d3a']
    if (bank, pc) in CHR_ENTRY:
        return c_adapter('lift_ppu_copy_chr') + ['tst.l d0', 'beq.b 8f',
                'moveq #0,d2', 'moveq #0,d4', 'andi.b #253,d6', 'ori.b #1,d6',
                f'jmp {label(bank, CHR_ENTRY[bank, pc])}', '8:']
    return []


def rom_switches(regions, prg):
    """Read the jump tables and link their targets as native module entries."""
    fixed_windows = {(7, 0xe6a3): 5, (7, 0xe920): 5, (7, 0xe9e2): 5,
                     (7, 0xeb37): 2, (7, 0xfbb1): 4, (7, 0xfd7f): 4}
    tables = {}
    for bank in range(8):
        local = regions[bank]
        addresses = sorted(local)
        for pc, (raw, op, _) in local.items():
            if op != 'JSR' or int.from_bytes(raw[1:], 'little') != SWITCH_DISPATCH:
                continue
            table = pc + len(raw)
            where = bisect_right(addresses, pc)
            end = addresses[where] if where < len(addresses) else ORIGINS[bank] + 0x4000
            base = (bank << 14) + table - ORIGINS[bank]
            window = fixed_windows.get((bank, pc), bank)
            targets = []
            for i in range(min(127, (end - table) // 2)):
                offset = base + 2 * i
                addr = int.from_bytes(prg[offset:offset + 2], 'little')
                if resolve(regions, window, addr) is None:
                    break
                targets.append((static_target(window, addr)[0], addr))
            if not targets:
                raise ValueError(f'Unmapped jump table at {bank}:{pc:04x}')
            tables[bank, pc] = window, targets
    return tables


def emit_native_switch(bank, pc, window, count):
    original_return = pc + 2
    high, low = original_return >> 8, original_return & 255
    code = ['moveq #0,d0', f'move.b {ACC},d0', f'cmpi.b #{count},d0', 'bcc.b 8f']
    if window != bank:
        code += [f'cmpi.b #{window},LIFT_LOW(a2)', 'bne.b 8f']
    code += [f'move.b d0,{Y}', f'add.b {Y},{Y}', f'addq.b #2,{Y}',
             f'move.w #{(low << 8) | high},(a2)', 'lsl.w #3,d0', f'lea switch_{bank}_{pc:04x},a0',
             'move.w 4(a0,d0.w),d1', 'move.w d1,2(a2)', f'move.b d1,{ACC}', f'andi.b #242,{P}',
             f'or.b 6(a0,d0.w),{P}', 'movea.l 0(a0,d0.w),a0', 'jmp (a0)',
             '8:', f'move.w {addr_imm(pc)},d0', 'jmp lift_native_fault']
    return code


def emit_switch_data(tables):
    lines = []
    for (bank, pc), (_, targets) in sorted(tables.items()):
        lines.append(f'switch_{bank}_{pc:04x}:')
        for target_bank, addr in targets:
            lines.extend((f'.long {label(target_bank, addr)}', f'.byte {addr & 255},{addr >> 8}',
                          f'.byte {8 if addr & 0x8000 else 0},0'))
    return lines


def strip_replaced_blocks(regions, switches):
    """Remove the interiors of routines with complete native replacements."""
    removed = {bank: set() for bank in regions}
    removed[7].update(pc for pc in regions[7] if SWITCH_DISPATCH <= pc < 0xe5f7)
    for (bank, start), end in NATIVE_BLOCKS.items():
        removed[bank].update(pc for pc in regions[bank] if start < pc < end)
    for bank, local in regions.items():
        for pc, (raw, op, mode) in local.items():
            if pc in removed[bank] or (bank, pc) in switches:
                continue
            if op in BRANCH_READ:
                target = bank, branch_target(pc, raw[1])
            elif op in ('JMP', 'JSR') and mode == 'abs':
                target = static_target(bank, int.from_bytes(raw[1:], 'little'))
            else:
                continue
            if target[1] in removed[target[0]]:
                raise ValueError(f'Jump from {bank}:{pc:04x} into a replaced block')
    if any(pc in removed[bank] for _, targets in switches.values() for bank, pc in targets):
        raise ValueError('Switch table points inside a replaced block')
    for bank, slots in removed.items():
        for pc in slots:
            del regions[bank][pc]


def emit_bank(regions, bank, routines, incoming, live, requested, switches):
    local = regions[bank]
    spans, skipped = repeat_spans(local, {pc for pc in local if fast_entry(bank, pc)})
    fused = fusion_points(local)
    moved = set(fused.values()) | skipped
    bounded = bounded_loops(local)
    carry_entries = {}
    for pc, (raw, op, _) in local.items():
        if op in ('CLC', 'SEC'):
            next_pc = pc + len(raw)
            if local.get(next_pc, (None, None, None))[1] == ('ADC' if op == 'CLC' else 'SBC'):
                carry_entries[pc] = next_pc, int(op == 'SEC')
    moved_arithmetic = {pc for pc, _ in carry_entries.values()}

    def near_branch(pc):
        raw, op, _ = local[pc]
        if op not in BRANCH_READ:
            return False
        target = branch_target(pc, raw[1])
        return target in local and target not in moved and target not in moved_arithmetic

    lines = []
    for pc in sorted(local):
        if pc in moved or pc in moved_arithmetic:
            continue
        entry = local[pc]
        raw, op, _ = entry
        following = pc + len(raw)
        lines.append(f'{label(bank, pc)}:')
        fast = fast_entry(bank, pc)
        lines.extend(fast)
        if fast and fast[-1].startswith('jmp '):
            continue
        count = spans.get(pc, pc) - pc + 1
        if count > 1:
            pc += count - 1
            entry = local[pc]
            raw, op, _ = entry
            following = pc + len(raw)
        carry = None
        if pc in carry_entries:
            pc, carry = carry_entries[pc]
            entry = local[pc]
            raw, op, _ = entry
            following = pc + len(raw)
        operand = int.from_bytes(raw[1:], 'little')
        test, edges = fusion_flags(local, pc, incoming) if pc in fused else (0, ((), ()))
        if (bank, pc) in switches:
            window, targets = switches[bank, pc]
            lines.extend(emit_native_switch(bank, pc, window, len(targets)))
            continue
        direct = op == 'JSR' and following in local
        native_call = direct and static_target(bank, operand) in routines
        if count > 1:
            lines.extend(lower_repeat(op, count, 0 if test else live[pc]))
        elif native_call:
            lines.extend(call_direct(bank, operand, following, live[pc], requested))
        else:
            lines.extend(lower(regions, bank, pc, entry, 0 if test else live[pc], near_branch(pc), pc in bounded,
                               carry, test))
        if pc in fused:
            ins, control, _ = local[following]
            lines.extend(branch(regions, bank, following, control, ins[1], native=True,
                                invert_carry=op in ('CMP', 'CPX', 'CPY', 'SBC'),
                                near=near_branch(following), bounded=following in bounded, edges=edges))
            following += len(ins)
        if (direct or op not in ('JMP', 'JSR', 'RTI', 'RTS')) and (
                following not in local or following in moved or following in moved_arithmetic):
            lines.extend(jump(regions, bank, following))
    # Keep original addresses available for indirect entries and guest returns.
    for pc in sorted(moved | moved_arithmetic):
        lines.extend([f'{label(bank, pc)}:'] + lower(regions, bank, pc, local[pc], live[pc])
                     + jump(regions, bank, pc + len(local[pc][0])))
    return lines


def emit_table(bank, pc_map):
    def missing(count):
        return [f'.rept {count}', '.long lift_native_fault', '.endr']

    def half(start, end):
        current = start
        out = []
        for pc in sorted(pc for pc in pc_map if start <= pc < end):
            if pc != current:
                out.extend(missing(pc - current))
            out.append(f'.long {label(bank, pc)}')
            current = pc + 1
        if end != current:
            out.extend(missing(end - current))
        return out

    base = ORIGINS[bank]
    entry = [f'.globl lift_pc_{bank}', f'lift_pc_{bank}:']
    if bank == 8:
        return entry + half(base, base + 0x2000)
    # Word indexing on 68000 sign-extends the displacement. The upper half of
    # each PRG table sits before its anchor, keeping an entire bank addressable.
    return half(base + 0x2000, base + 0x4000) + entry + half(base, base + 0x2000)


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('rom', type=Path)
    parser.add_argument('--output', type=Path, default=root / 'src/generated/m68k_program.s')
    args = parser.parse_args()
    image = args.rom.read_bytes()
    if hashlib.sha256(image).hexdigest() != PRG0_SHA256:
        parser.error('Expected the verified Zelda PRG0 image.')
    regions = read_catalogue(root / 'data/prg0_instructions.json.gz', image[16:])
    switches = rom_switches(regions, image[16:])
    strip_replaced_blocks(regions, switches)
    routines = native_routines(regions)
    analyse, variant = flag_dependencies(regions, routines)
    requested = set()
    lines = ['/* Generated from the verified PRG0 instruction map. */', '#include "lift_layout.h"', '.text', '.align 2',
             '.globl prg_5_aad0,prg_5_aaf0,prg_7_e484,prg_7_e53b,prg_7_e55c,prg_7_e678',
             '.globl prg_8_6d0b,prg_8_6e2c,prg_8_6e6d,prg_8_701e,prg_8_78b6',
             '.globl prg_8_7868,prg_8_7af4,prg_8_7bef']
    for bank in sorted(regions):
        incoming, live = analyse(bank, regions[bank], STATUS_FLAGS)
        lines.extend(emit_bank(regions, bank, routines, incoming, live, requested, switches))
    emitted = set()
    while requested - emitted:
        for bank, start, wanted in sorted(requested - emitted):
            _, incoming, live = variant(bank, start, wanted)
            lines.extend(emit_native_routine(regions, bank, start, wanted, routines[bank, start], incoming, live, requested))
            emitted.add((bank, start, wanted))
    lines.extend(('.section .rodata', '.align 2'))
    lines.extend(emit_switch_data(switches))
    for bank in sorted(regions):
        lines.extend(emit_table(bank, regions[bank]))
    lines.extend(('.globl lift_pc_invalid', '.rept 8192', '.long lift_native_fault', '.endr',
                  'lift_pc_invalid:', '.rept 8192', '.long lift_native_fault', '.endr'))
    update_generated(args.output, '\n'.join(line if line.endswith(':') or line.startswith(('#', '/*')) else '    ' + line for line in lines) + '\n')


if __name__ == '__main__':
    main()

"""Small two-pass MC68000 assembler for the port's generated instruction subset."""
import re, bisect
from collections import defaultdict
from functools import lru_cache

@lru_cache(maxsize=None)
def splitargs(s):
    return tuple(re.split(r',\s*(?![^()]*\))',s)) if s else ()

def assemble(source, constants, external, text_start, data_start, hint=None):
    records=[]; labels=dict(external); hint=hint or {}; numeric=defaultdict(list); section=0; repeat=1
    for line in source.splitlines():
        line=line.strip()
        if not line or line.startswith(('/*','#','.globl','.align')):continue
        if line=='.text':section=0;continue
        if line=='.section .rodata':section=1;continue
        if line.startswith('.rept '):repeat=int(line[6:]);continue
        if line=='.endr':repeat=1;continue
        if line.endswith(':'):
            records.append((section,line[:-1],(),0));continue
        op,_,args=line.partition(' ');records.append((section,op,splitargs(args),repeat))
    def word(n):return (n&65535).to_bytes(2,'big')
    def long(n):return (n&0xffffffff).to_bytes(4,'big')
    def reg(s):return 7 if s=='sp' else int(s[1])
    def isd(s):return len(s)==2 and s[0]=='d' and s[1].isdigit()
    def isa(s):return s=='sp' or len(s)==2 and s[0]=='a' and s[1].isdigit()
    def num(s,pc,idx,first):
        if re.fullmatch(r'[0-9]+[fb]',s):
            if first:return 0
            a=numeric[s[:-1]];i=bisect.bisect_left(a,(idx,-1))
            return a[i if s[-1]=='f' else i-1][1]
        if s in labels:return labels[s]
        if s in constants:return constants[s]
        try:return int(s,0)
        except ValueError:pass
        if '+' in s:
            a,b=s.split('+',1);return num(a,pc,idx,first)+num(b,pc,idx,first)
        if first:return 0
        raise ValueError('Unknown expression '+s)
    def ea(s,size,pc,idx,first):
        if isd(s):return reg(s),b''
        if isa(s):return 8+reg(s),b''
        if s.startswith('#'):
            v=num(s[1:],pc,idx,first);return 60,long(v) if size==2 else word(v if size==1 else v&255)
        m=re.fullmatch(r'\((a[0-7]|sp)\)(\+)?',s)
        if m:return (24 if m[2] else 16)+reg(m[1]),b''
        m=re.fullmatch(r'-\((a[0-7]|sp)\)',s)
        if m:return 32+reg(m[1]),b''
        m=re.fullmatch(r'(.*)\((a[0-7]|sp)(?:,([da][0-7])\.([wl]))?\)',s)
        if m:
            disp=num(m[1] or '0',pc,idx,first);r=reg(m[2])
            if m[3]:return 48+r,word((0x8000 if m[3][0]=='a' else 0)|(reg(m[3])<<12)|(0x800 if m[4]=='l' else 0)|(disp&255))
            if disp==0:return 16+r,b''
            return 40+r,word(disp)
        return 57,long(num(s,pc,idx,first))
    def enc(op,a,pc,idx,first):
        if op=='.byte':return bytes(num(x,pc,idx,first)&255 for x in a)
        if op=='.long':return b''.join(long(num(x,pc,idx,first)) for x in a)
        name,_,suffix=op.partition('.');size={'b':0,'w':1,'l':2,'':1}[suffix]
        E=lambda s:ea(s,size,pc,idx,first)
        N=lambda s:num(s.lstrip('#'),pc,idx,first)
        if name=='rts':return word(0x4e75)
        if name=='moveq':return word(0x7000|reg(a[1])<<9|N(a[0])&255)
        if name in ('move','movea'):
            if a[0]=='sr':m,e=E(a[1]);return word(0x40c0|m)+e
            sm,se=E(a[0]);dm,de=E(a[1]);return word((0x1000,0x3000,0x2000)[size]|(dm&7)<<9|(dm>>3)<<6|sm)+se+de
        if name in ('jmp','jsr','pea','lea'):
            m,e=E(a[0]);
            if a[0].startswith('.Lreturn_') or (a[0] in hint and -32768<=hint[a[0]]-pc-2<=32767 and a[0].startswith(('prg_','fast_'))):
                m,e=58,word(N(a[0])-pc-2)
            base={'jmp':0x4ec0,'jsr':0x4e80,'pea':0x4840,'lea':0x41c0}[name]
            return word(base|m|(reg(a[1])<<9 if name=='lea' else 0))+e
        cond={'bra':0,'bsr':1,'bhi':2,'bls':3,'bcc':4,'bcs':5,'bne':6,'beq':7,'bvc':8,'bvs':9,'bpl':10,'bmi':11,'bge':12,'blt':13,'bgt':14,'ble':15}
        if name in cond:
            v=N(a[0])-pc-2;base=0x6000|cond[name]<<8
            if suffix=='b':
                if not first and (not -128<=v<=127 or v==0):raise ValueError(f'Branch {op} {a} at {pc:x}: {v}')
                return word(base|(v&255))
            return word(base)+word(v)
        if name=='btst':m,e=E(a[1]);return word(0x0800|m)+word(N(a[0]))+e
        if name in ('addq','subq'):
            m,e=E(a[1]);return word(0x5000|((N(a[0])&7)<<9)|(0x100 if name=='subq' else 0)|size<<6|m)+e
        if name in ('ori','andi','subi','addi','eori','cmpi'):
            if a[1]=="ccr":return word({"ori":0x003c,"andi":0x023c,"eori":0x0a3c}[name])+word(N(a[0])&255)
            m,e=E(a[1]);v=N(a[0]);base={'ori':0,'andi':0x200,'subi':0x400,'addi':0x600,'eori':0xa00,'cmpi':0xc00}[name]
            return word(base|size<<6|m)+(long(v) if size==2 else word(v if size==1 else v&255))+e
        if name in ('addx','subx'):
            return word((0xd100 if name=='addx' else 0x9100)|reg(a[1])<<9|size<<6|reg(a[0]))
        if name in ('or','and','add','sub','cmp','eor'):
            base={'or':0x8000,'and':0xc000,'add':0xd000,'sub':0x9000,'cmp':0xb000,'eor':0xb000}[name]
            if isd(a[1]) and name!='eor':m,e=E(a[0]);return word(base|reg(a[1])<<9|size<<6|m)+e
            m,e=E(a[1]);return word(base|reg(a[0])<<9|(size+4)<<6|m)+e
        if name in ('not','tst'):
            m,e=E(a[0]);return word((0x4600 if name=='not' else 0x4a00)|size<<6|m)+e
        if name in ('lsr','lsl','ror','rol','roxr','roxl','asr','asl'):
            t={'as':0,'ls':1,'rox':2,'ro':3}[name[:-1]];return word(0xe000|(N(a[0])&7)<<9|(0x100 if name.endswith('l') else 0)|size<<6|t<<3|reg(a[1]))
        raise ValueError('Unsupported opcode '+op)
    starts=[text_start,data_start]
    for first in (True,False):
        pos=starts[:]; out=[bytearray(),bytearray()]
        for idx,(sec,op,a,r) in enumerate(records):
            pc=pos[sec]
            if r==0:
                if first:
                    if op.isdigit():numeric[op].append((idx,pc))
                    else:labels[op]=pc
                continue
            try:b=enc(op,a,pc,idx,first)*r
            except Exception as e:raise ValueError(f'{pc:06x}: {op} {a}: {e}') from e
            if not first:out[sec].extend(b)
            pos[sec]+=len(b)
    return out,labels

"""Deterministic single-input build. No external compiler or SDK at runtime."""
from pathlib import Path
import hashlib,json,sys,struct,tempfile
from assemble import assemble
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'engine/tools'))
import translate_68k,build_art

def sha(b):return hashlib.sha256(b).hexdigest()
def check(b,expected,label):
    if sha(b)!=expected:raise ValueError(f'{label}: SHA-256 mismatch ({sha(b)})')
def ips(data,patch):
    if patch[:5]!=b'PATCH':raise ValueError('Invalid IPS header')
    out=bytearray(data);p=5
    while True:
        if patch[p:p+3]==b'EOF':
            if p+3!=len(patch):raise ValueError('Invalid IPS end')
            return bytes(out)
        if p+5>len(patch):raise ValueError('Truncated IPS')
        a=int.from_bytes(patch[p:p+3],'big');n=int.from_bytes(patch[p+3:p+5],'big');p+=5
        if n:chunk=patch[p:p+n];p+=n
        else:
            n=int.from_bytes(patch[p:p+2],'big');chunk=patch[p+2:p+3]*n;p+=3
        if not n or len(chunk)!=n or a+n>len(out):raise ValueError('Invalid IPS bounds')
        out[a:a+n]=chunk

def build(image,log=print):
    image=bytes(image);m=json.loads((ROOT/'manifest.json').read_text());l=json.loads((ROOT/'layout.json').read_text())
    if len(image)!=131088 or image[:4]!=b'NES\x1a':raise ValueError('Expected a 131,088-byte USA PRG0 iNES ROM.')
    check(image,m['input_sha256'],'NES PRG0');log('Original NES ROM verified.')
    runtime=(ROOT/'runtime.dat').read_bytes();check(runtime,l['runtime_sha256'],'Native runtime')
    out=bytearray(l['size']);p=0
    for a,n in l['segments']:out[a:a+n]=runtime[p:p+n];p+=n
    if p!=len(runtime):raise ValueError('Invalid runtime layout')
    with tempfile.TemporaryDirectory() as temp:
        rom=Path(temp)/'input.nes';rom.write_bytes(image);asm=Path(temp)/'program.s'
        argv=sys.argv[:]
        try:
            sys.argv=['translate_68k.py',str(rom),'--output',str(asm)];translate_68k.main()
        finally:sys.argv=argv
        log('6502 logic translated to native MC68000 assembly.')
        chunks,labels=assemble(asm.read_text(),l['constants'],l['external'],l['text_start'],l['data_start'],hint=l['relaxation_layout'])
        for (a,b),chunk in zip(l['holes'][:2],chunks):
            if len(chunk)!=b-a:raise ValueError('Unexpected translated code layout')
            out[a:b]=chunk
        if any(labels.get(k)!=v for k,v in l['relaxation_layout'].items()):raise ValueError('Translated label layout mismatch')
    log('68000 machine code and dispatch tables assembled.')
    prg=image[16:];out[l['prg']:l['prg']+len(prg)]=prg
    tiles=[bytes(16)];spans=[]
    for a,b in build_art.pattern_ranges(prg):
        spans.append((a,len(tiles),(b-a)//16));tiles.extend(prg[i:i+16] for i in range(a,b,16))
    for pal,a in enumerate(l['art']):
        art=b''.join(struct.pack('>8I',*build_art.tile_rows(t,pal)) for t in tiles)
        if len(art)!=0x95a0:raise ValueError('Unexpected art size')
        out[a:a+len(art)]=art
    data=b''.join(struct.pack('>IHH',*span) for span in spans)
    out[l['spans']:l['spans']+len(data)]=data;out[l['span_count']:l['span_count']+2]=struct.pack('>H',len(spans))
    out[l['palette_ptrs']:l['palette_ptrs']+16]=struct.pack('>4I',*l['art'])
    log('Original PRG data and VDP tile graphics reconstructed.')
    check(out,m['base_sha256'],'Rebuilt MD13');log('MD13 base verified byte for byte by SHA-256.')
    for step in m['overlays']:
        patch=(ROOT/'overlays'/step['file']).read_bytes();check(patch,step['patch_sha256'],'Overlay');out=ips(out,patch);check(out,step['output_sha256'],step['file'])
    check(out,m['output_sha256'],'Final MD35')
    checksum=sum(int.from_bytes(out[i:i+2],'big') for i in range(0x200,len(out),2))&65535
    if checksum!=int.from_bytes(out[0x18e:0x190],'big') or out[0x100:0x104]!=b'SEGA':raise ValueError('Invalid Mega Drive header/checksum')
    log('MD35 verified: exact reference SHA-256 and valid Mega Drive checksum.')
    return bytes(out)
